import boto3
import json

dynamodb = boto3.resource(
    'dynamodb',
    endpoint_url='http://localhost:4566'
)

table = dynamodb.Table('Roles')


def lambda_put_item(body):
    table.put_item(Item={
        'id': body['id'],
        'type': body['type'],
        'permissions': body.get('permissions', {})
    })

def lambda_get_item(body):
    response = table.get_item(Key={'id': body['id']})
    return response.get('Item')

def lambda_update_item(body):
    table.update_item(
        Key={'id': body['id']},
        UpdateExpression='SET #t = :t, #p = :p',
        ExpressionAttributeNames={
            '#t': 'type',
            '#p': 'permissions'  # alias
        },
        ExpressionAttributeValues={
            ':t': body['type'],
            ':p': body.get('permissions', {})
        }
    )

def lambda_delete_item(body):
    table.delete_item(Key={'id': body['id']})

def lambda_handler(event):
    try:
        body = json.loads(event['body'])
        action = event.get('action')

        if action == 'put':
            lambda_put_item(body)
            return {'statusCode': 200, 'body': json.dumps({'message': 'Item added'})}
        elif action == 'get':
            item = lambda_get_item(body)
            return {'statusCode': 200, 'body': json.dumps(item or {})}
        elif action == 'update':
            lambda_update_item(body)
            return {'statusCode': 200, 'body': json.dumps({'message': 'Item updated'})}
        elif action == 'delete':
            lambda_delete_item(body)
            return {'statusCode': 200, 'body': json.dumps({'message': 'Item deleted'})}
        else:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid action'})}

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
